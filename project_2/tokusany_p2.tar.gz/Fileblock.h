#ifndef FILEBLOCK_H
#define FILEBLOCK_H

class Fileblock {
public:
    Fileblock();
    ~Fileblock();
    unsigned int getID() const;
    void set_payload(const char* Payload);
    bool validate_checksum() const;
    int id;
    int compute_checksum() const;
    void setChecksum(int checksum);
    int getStoredChecksum() const;

private:
    char payload[501]; 
    int storedChecksum;
};

#endif